# Wook Search Engine — MVP

Wook의 자체 검색 백엔드 시작 프로젝트입니다. Google/Naver/Yandex 검색 API를 호출하지 않습니다.
자신이 허용한 웹사이트를 직접 수집해 SQLite FTS5 색인에 저장하고, Wook 검색 API가 결과를 반환합니다.

## 포함 기능
- FastAPI 검색 API: `GET /api/search?q=...`
- SQLite FTS5 자체 검색 색인
- URL 시드 목록 기반의 제한적 크롤러
- `robots.txt` 확인, 도메인 allowlist, 요청 간 지연, 페이지 수 제한
- Netlify 정적 프런트엔드에서 호출할 수 있는 API
- Docker 실행 구성

## 로컬 실행 (Python 3.11+)
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
API 문서: http://127.0.0.1:8000/docs  
상태 확인: http://127.0.0.1:8000/health

## 크롤러 사용
1. `seeds.txt`에 본인이 수집할 권한이 있거나 공개적으로 크롤링이 허용된 웹사이트 URL을 한 줄에 하나씩 입력합니다.
2. `CRAWL_ALLOWED_DOMAINS` 환경변수에 허용 도메인을 쉼표로 지정합니다. 예: `docs.python.org,example.com`
3. 서버를 실행한 뒤:
```bash
python -m app.crawler
```
기본값은 최대 100페이지이며 `CRAWL_MAX_PAGES`로 조절할 수 있습니다.
크롤러는 robots.txt를 존중하고 페이지 사이에 지연을 둡니다. 로그인·유료벽·접근 제한을 우회하지 마세요.

## Netlify 프런트엔드 연결
Netlify 사이트의 검색 코드에서 검색을 실행할 때 다음처럼 요청합니다:
```js
const API_BASE = "https://YOUR-BACKEND-DOMAIN";
const response = await fetch(
  `${API_BASE}/api/search?q=${encodeURIComponent(query)}`
);
const data = await response.json();
```
`YOUR-BACKEND-DOMAIN`을 실제 백엔드 주소로 바꾸세요. 백엔드의 `CORS_ORIGINS` 환경변수에 정확한 Netlify 사이트 주소를 설정하세요. 예:
`https://stupendous-gumption-d17e2c.netlify.app`

## Docker
Docker가 설치된 환경에서:
```bash
docker compose up --build
```
이 구성은 API를 8000 포트로 실행합니다. SQLite 데이터는 `./data`에 저장됩니다.

## 현재 한계
- 검색 가능한 것은 크롤링해서 색인에 저장한 페이지만입니다. 인터넷 전체를 즉시 검색하지는 않습니다.
- 이 MVP는 데모용이며 큰 규모의 검색엔진 운영에는 분산 색인, 중복 제거, 재크롤링 일정, 악성 URL 방어, 모니터링 등이 추가로 필요합니다.
- 실제 배포 시 공개 검색 API에 속도 제한을 적용하고, 서버·DB 백업 및 보안 설정을 하세요.
