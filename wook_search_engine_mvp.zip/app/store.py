import os
import sqlite3
from urllib.parse import urlsplit
from .config import DATABASE_PATH

def connect():
    folder = os.path.dirname(os.path.abspath(DATABASE_PATH))
    os.makedirs(folder, exist_ok=True)
    db = sqlite3.connect(DATABASE_PATH)
    db.row_factory = sqlite3.Row
    return db

def init_db():
    with connect() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS pages (
                url TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                description TEXT NOT NULL DEFAULT '',
                content TEXT NOT NULL DEFAULT '',
                domain TEXT NOT NULL,
                fetched_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)
        # FTS5 is SQLite's built-in full-text search. Rebuild only if needed.
        db.execute("""
            CREATE VIRTUAL TABLE IF NOT EXISTS pages_fts USING fts5(
                url UNINDEXED, title, description, content,
                tokenize='unicode61'
            )
        """)
        db.execute("""
            CREATE TRIGGER IF NOT EXISTS pages_ai AFTER INSERT ON pages BEGIN
                INSERT INTO pages_fts(rowid, url, title, description, content)
                VALUES (new.rowid, new.url, new.title, new.description, new.content);
            END
        """)
        db.execute("""
            CREATE TRIGGER IF NOT EXISTS pages_ad AFTER DELETE ON pages BEGIN
                DELETE FROM pages_fts WHERE rowid = old.rowid;
            END
        """)
        db.execute("""
            CREATE TRIGGER IF NOT EXISTS pages_au AFTER UPDATE ON pages BEGIN
                DELETE FROM pages_fts WHERE rowid = old.rowid;
                INSERT INTO pages_fts(rowid, url, title, description, content)
                VALUES (new.rowid, new.url, new.title, new.description, new.content);
            END
        """)

def upsert_page(url: str, title: str, description: str, content: str):
    domain = urlsplit(url).hostname or ""
    with connect() as db:
        db.execute("""
            INSERT INTO pages(url,title,description,content,domain,fetched_at)
            VALUES(?,?,?,?,?,CURRENT_TIMESTAMP)
            ON CONFLICT(url) DO UPDATE SET
                title=excluded.title, description=excluded.description,
                content=excluded.content, domain=excluded.domain,
                fetched_at=CURRENT_TIMESTAMP
        """, (url, title[:500], description[:1000], content[:100000], domain))

def search_pages(query: str, limit: int = 10):
    # Quote user input as a phrase so FTS operators cannot be injected.
    phrase = '"' + query.replace('"', '""') + '"'
    with connect() as db:
        try:
            rows = db.execute("""
                SELECT p.url, p.title, p.description, p.domain, p.fetched_at,
                       snippet(pages_fts, 3, '<mark>', '</mark>', ' … ', 18) AS snippet,
                       bm25(pages_fts, 0.0, 5.0, 2.0, 1.0) AS rank
                FROM pages_fts
                JOIN pages p ON p.rowid = pages_fts.rowid
                WHERE pages_fts MATCH ?
                ORDER BY rank
                LIMIT ?
            """, (phrase, limit)).fetchall()
            return [dict(row) for row in rows]
        except sqlite3.OperationalError:
            return []
