from contextlib import asynccontextmanager
from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from .config import CORS_ORIGINS
from .store import init_db, search_pages

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield

app = FastAPI(
    title="Wook Search API",
    description="Search only pages indexed by Wook's own crawler.",
    version="0.1.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=False,
    allow_methods=["GET"],
    allow_headers=["*"],
)

@app.get("/health")
def health():
    return {"ok": True, "service": "wook-search-api"}

@app.get("/api/search")
def search(q: str = Query(min_length=1, max_length=200), page: int = Query(1, ge=1, le=100)):
    results = search_pages(q.strip(), limit=min(10, 10))
    return {
        "query": q,
        "page": page,
        "results": [
            {
                "title": row["title"] or row["url"],
                "url": row["url"],
                "description": row["description"],
                "domain": row["domain"],
                "snippet": row["snippet"],
                "lastIndexed": row["fetched_at"],
            } for row in results
        ],
        "totalReturned": len(results),
        "source": "wook-index",
    }
