import asyncio
import time
from collections import deque
from urllib.parse import urljoin, urlparse, urldefrag
from urllib.robotparser import RobotFileParser

import httpx
from bs4 import BeautifulSoup

from .config import ALLOWED_DOMAINS, CRAWL_DELAY_SECONDS, MAX_PAGES, USER_AGENT
from .store import init_db, upsert_page

def normalize_url(url: str) -> str | None:
    url, _ = urldefrag(url)
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        return None
    if parsed.username or parsed.password:
        return None
    if parsed.hostname.lower() not in ALLOWED_DOMAINS:
        return None
    if parsed.path.lower().endswith((".pdf", ".jpg", ".jpeg", ".png", ".gif", ".zip", ".mp4", ".mp3")):
        return None
    return url

async def load_robots(client: httpx.AsyncClient, origin: str) -> RobotFileParser:
    parser = RobotFileParser()
    robots_url = origin.rstrip("/") + "/robots.txt"
    parser.set_url(robots_url)
    try:
        response = await client.get(robots_url, timeout=10)
        if response.status_code == 200:
            parser.parse(response.text.splitlines())
        else:
            # If robots.txt cannot be retrieved, crawl conservatively by skipping this origin.
            parser.parse(["User-agent: *", "Disallow: /"])
    except httpx.HTTPError:
        parser.parse(["User-agent: *", "Disallow: /"])
    return parser

async def crawl():
    init_db()
    seeds = []
    try:
        with open("seeds.txt", encoding="utf-8") as f:
            seeds = [line.strip() for line in f if line.strip() and not line.lstrip().startswith("#")]
    except FileNotFoundError:
        print("seeds.txt not found")
        return

    headers = {"User-Agent": USER_AGENT}
    timeout = httpx.Timeout(15.0, connect=8.0)
    queue = deque(filter(None, (normalize_url(url) for url in seeds)))
    seen = set()
    robots_by_origin = {}
    indexed = 0
    async with httpx.AsyncClient(headers=headers, follow_redirects=True, timeout=timeout) as client:
        while queue and indexed < MAX_PAGES:
            url = queue.popleft()
            if url in seen:
                continue
            seen.add(url)
            parsed = urlparse(url)
            origin = f"{parsed.scheme}://{parsed.netloc}"
            if origin not in robots_by_origin:
                robots_by_origin[origin] = await load_robots(client, origin)
            if not robots_by_origin[origin].can_fetch(USER_AGENT, url):
                print(f"robots.txt disallows: {url}")
                continue
            try:
                response = await client.get(url)
                if response.status_code != 200:
                    continue
                content_type = response.headers.get("content-type", "").lower()
                if "text/html" not in content_type:
                    continue
                soup = BeautifulSoup(response.text, "html.parser")
                for tag in soup(["script", "style", "noscript", "svg", "nav", "footer"]):
                    tag.decompose()
                title = soup.title.get_text(" ", strip=True) if soup.title else url
                meta = soup.find("meta", attrs={"name": "description"})
                description = meta.get("content", "").strip() if meta else ""
                content = soup.get_text(" ", strip=True)
                if content:
                    upsert_page(url, title, description, content)
                    indexed += 1
                    print(f"[{indexed}/{MAX_PAGES}] indexed {url}")
                for link in soup.find_all("a", href=True):
                    target = normalize_url(urljoin(url, link["href"]))
                    if target and target not in seen:
                        queue.append(target)
            except (httpx.HTTPError, UnicodeError, ValueError) as exc:
                print(f"skip {url}: {exc}")
            await asyncio.sleep(max(CRAWL_DELAY_SECONDS, 1.0))
    print(f"Finished. Pages indexed this run: {indexed}")

if __name__ == "__main__":
    asyncio.run(crawl())
