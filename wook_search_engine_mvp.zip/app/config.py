import os

def csv_env(name: str, default: str = "") -> list[str]:
    return [item.strip().lower() for item in os.getenv(name, default).split(",") if item.strip()]

DATABASE_PATH = os.getenv("DATABASE_PATH", "./data/wook.db")
CORS_ORIGINS = [x.strip() for x in os.getenv(
    "CORS_ORIGINS",
    "https://stupendous-gumption-d17e2c.netlify.app,http://localhost:3000"
).split(",") if x.strip()]
ALLOWED_DOMAINS = set(csv_env("CRAWL_ALLOWED_DOMAINS", "example.com,docs.python.org"))
MAX_PAGES = int(os.getenv("CRAWL_MAX_PAGES", "100"))
CRAWL_DELAY_SECONDS = float(os.getenv("CRAWL_DELAY_SECONDS", "2.0"))
USER_AGENT = os.getenv("USER_AGENT", "WookBot/0.1 (+contact: replace-with-your-contact-email)")
